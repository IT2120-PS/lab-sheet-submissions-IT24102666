##Part 1
#Setting Directory
setwd("C:/Users/it24102666/Desktop/IT24102666/2025 SEM/LAB SUBMISSION/LAB 04")

##Importing the data set
data <- read.table("C:/Users/it24102666/Desktop/IT24102666/2025 SEM/LAB SUBMISSION/LAB 04/DATA 4.txt", header = TRUE, sep = " ")

##view the file in a separate window
fix(data)

##Attach the file into R. So, you can call the variables by their names.
attach(data)

##Part 2
##Part (a)
#Obtaining Box Plots
boxplot(X1, main="Box plot for Team Attendance", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)

#Obtaining Histogram
hist(X1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

#Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

##Part (b)
##Mean
mean(X1)
mean(X2)
mean(X3)

##Median
median(X1)
median(X2)
median(X3)

##Standard Deviation
sd(X1)
sd(X2)
sd(X3)

##Part (d)
##Obtaining Inter Quartile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)




# Importing the dataset into R
branch_data <- read.table("C:/Users/it24102666/Desktop/IT24102666/2025 SEM/LAB SUBMISSION/LAB 04/Exercise.txt", header = TRUE, sep = "\t")

# Viewing the first few rows of the data
head(branch_data)

# Check the structure of the dataset
str(branch_data)

# Boxplot for the sales variable
boxplot(branch_data$Sales, main = "Boxplot for Sales", ylab = "Sales", col = "lightblue")

# Interpretation: Look at the spread, central tendency (median), and potential outliers.

# Function to find outliers in a numeric vector
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  # Outliers are values outside of the lower and upper bounds
  outliers <- x[x < lower_bound | x > upper_bound]
  
  return(outliers)
}

# Check for outliers in the 'Years' variable
find_outliers(branch_data$Years)





